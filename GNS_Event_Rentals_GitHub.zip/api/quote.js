const crypto = require('node:crypto');
const products = require('../assets/catalog.js');
const byId = Object.assign(Object.create(null),Object.fromEntries(products.map(p=>[p.id,p])));
const rateBuckets = new Map();
const validDate = d => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(Date.parse(d)) && new Date(d).toISOString().slice(0,10)===d;
const text = (v,max) => typeof v==='string'?v.trim().slice(0,max):'';
module.exports = async (req,res) => {
  res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST'){res.setHeader('Allow','POST');return res.status(405).json({ok:false,message:'Use POST to submit a request.'})}
  const origin=req.headers.origin;
  if(origin){try{if(new URL(origin).host!==req.headers.host)return res.status(403).json({ok:false,message:'Please submit your request from the GNS website.'});}catch{return res.status(403).json({ok:false,message:'Invalid origin.'})}}
  if(!String(req.headers['content-type']||'').startsWith('application/json'))return res.status(415).json({ok:false,message:'Please submit a JSON request.'});
  if(Number(req.headers['content-length']||0)>24000)return res.status(413).json({ok:false,message:'Request is too large.'});
  let data;
  try{data=typeof req.body==='string'?JSON.parse(req.body):req.body;}catch{return res.status(400).json({ok:false,message:'Please check your request.'})}
  if(!data||typeof data!=='object'||Array.isArray(data)||JSON.stringify(data).length>24000)return res.status(400).json({ok:false,message:'Please check your request.'});
  if(data.website)return res.status(400).json({ok:false,message:'Unable to submit this request.'});
  const area=data.area;
  const name=text(data.name,100),email=text(data.email,180),date=text(data.date,10),endDate=text(data.endDate,10),location=text(data.location,180),occasion=text(data.occasion,100),service=text(data.service,100);
  if(!['dc','dfw'].includes(area)||!name||/[\r\n]/.test(name)||!/^\S+@\S+\.\S+$/.test(email)||/[\r\n]/.test(email)||!validDate(date)||new Date(date).getTime()+86400000<Date.now()||!location||!occasion||!service||data.consent!==true)return res.status(400).json({ok:false,message:'Please provide your name, valid email, service area, event date, event type, venue location, preferred service and consent.'});
  if(endDate&&(!validDate(endDate)||endDate<date))return res.status(400).json({ok:false,message:'Return date must be on or after the event date.'});
  if(data.guests&&(!/^\d+$/.test(String(data.guests))||Number(data.guests)<1||Number(data.guests)>100000))return res.status(400).json({ok:false,message:'Please enter a valid guest count.'});
  if(!Array.isArray(data.items)||data.items.length>products.length)return res.status(400).json({ok:false,message:'Please review your rental list.'});
  const seen=new Set();let subtotal=0;
  for(const i of data.items){if(!i||!byId[i.id]||seen.has(i.id)||!Number.isInteger(i.quantity)||i.quantity<1||i.quantity>999)return res.status(400).json({ok:false,message:'Please check selected items and quantities.'});seen.add(i.id);if(byId[i.id].markets[area]==='unavailable')return res.status(400).json({ok:false,message:'Please remove items not offered in your selected market.'});subtotal+=byId[i.id].price*i.quantity;}
  if(!process.env.RESEND_API_KEY||!process.env.QUOTE_TO_EMAIL||!process.env.QUOTE_FROM_EMAIL)return res.status(503).json({ok:false,code:'NOT_CONFIGURED',message:'Online quote delivery is not connected yet.'});
  // Best-effort per-instance throttling; add a Vercel Firewall rate-limit rule for public launch.
  const ip=String(req.headers['x-forwarded-for']||'unknown').split(',')[0];const key=crypto.createHash('sha256').update(ip).digest('hex');const now=Date.now();
  for(const [k,v] of rateBuckets)if(now-v.since>600000)rateBuckets.delete(k);
  const bucket=rateBuckets.get(key)||{since:now,count:0};if(bucket.count>=5)return res.status(429).json({ok:false,message:'Please wait a few minutes before sending another request.'});bucket.count++;rateBuckets.set(key,bucket);
  const reference='GNS-'+crypto.randomUUID().slice(0,8).toUpperCase();
  const currency=n=>'$'+n.toFixed(2);
  const lines=[`Quote reference: ${reference}`,`Service area: ${area==='dc'?'Washington, DC / Northern Virginia':'Dallas–Fort Worth, Texas'}`,`Event: ${occasion}`,`Event date: ${date}`,`End / return date: ${endDate||'To be confirmed'}`,`Guest count: ${text(String(data.guests||''),10)||'To be confirmed'}`,`Venue: ${text(data.venue,150)||'To be confirmed'}`,`Venue city / ZIP: ${location}`,`Service: ${service}`,'','RENTAL LIST',...data.items.map(i=>`${i.quantity} × ${byId[i.id].name} @ ${currency(byId[i.id].price)} = ${currency(byId[i.id].price*i.quantity)}`),`Estimated 24-hour rental subtotal: ${currency(subtotal)}`,'Delivery, setup, taxes and applicable charges are quoted separately. Inventory and rental terms require confirmation.','',`Name: ${name}`,`Email: ${email}`,`Phone: ${text(data.phone,35)}`,`Company: ${text(data.company,150)}`,'',`Notes: ${text(data.notes,3000)}`,'','Customer consented to using these details to respond to this quote request.'];
  try{
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.QUOTE_FROM_EMAIL,to:process.env.QUOTE_TO_EMAIL.split(',').map(v=>v.trim()).filter(Boolean),reply_to:email,subject:`${reference} | ${area==='dc'?'DC / NoVA':'DFW'} rental request | ${date}`,text:lines.join('\n')}),signal:AbortSignal.timeout(10000)});
    const responseData=await response.json();if(!response.ok||!responseData.id)return res.status(502).json({ok:false,message:'Email delivery is temporarily unavailable. Please try again or download your request.'});
    return res.status(200).json({ok:true,reference});
  }catch{return res.status(502).json({ok:false,message:'Email delivery is temporarily unavailable. Please try again or download your request.'})}
};
